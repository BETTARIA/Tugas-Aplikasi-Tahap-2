package datatas;

import datatas.model.TasProperty;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import datatas.db.DBHandler;
import datatas.model.TasProperty;



public class FXMLDataViewController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TableView<TasProperty> tblTas;

    @FXML
    private TableColumn<TasProperty, String> colId;

    @FXML
    private TableColumn<TasProperty, String> colMerk;

    @FXML
    private TableColumn<TasProperty, String> colJenis;

    @FXML
    private TableColumn<TasProperty, String> colTipe;

    @FXML
    private TableColumn<TasProperty, String> colTanggal_Produksi;

    @FXML
    private MenuItem menuAddData;

    @FXML
    private MenuItem menuDeleteData;

    @FXML
    void viewAddDataForm(ActionEvent event) throws IOException {
        Stage modal = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDataView.fxml"));
        Scene scene = new Scene(root);
        modal.setScene(scene);
//        modal.initOwner(((Node)event.getSource()).getScene().getWindow() );
        modal.initModality(Modality.APPLICATION_MODAL);
        modal.showAndWait();
    }

    @FXML
    void deleteDataTas(ActionEvent event) {
        TasProperty ts = tblTas.getSelectionModel().getSelectedItem();
        DBHandler dh = new DBHandler("MYSQL");
        dh.deleteDatatas(ts);
        showDataTas();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showDataTas();

        tblTas.getSelectionModel().selectedIndexProperty().addListener(listener -> {
//            JOptionPane.showMessageDialog(null, "Table Diklik!");
            menuDeleteData.setDisable(false);
        });
    }

    public void showDataTas() {
        DBHandler dh = new DBHandler("MYSQL");
        ObservableList<TasProperty> data = dh.Tas();
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colMerk.setCellValueFactory(new PropertyValueFactory<>("merk"));
        colJenis.setCellValueFactory(new PropertyValueFactory<>("jenis"));
        colTipe.setCellValueFactory(new PropertyValueFactory<>("tipe"));
        colTanggal_Produksi.setCellValueFactory(new PropertyValueFactory<>("tanggal_produksi"));
        tblTas.setItems(null);
        tblTas.setItems(data);
    }
}