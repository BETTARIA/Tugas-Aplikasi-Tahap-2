/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datatas.model;



import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class TasProperty {
    private StringProperty id;
    private StringProperty merk;
    private StringProperty jenis;
    private StringProperty tipe;
    private StringProperty tanggalProduksi;

    public TasProperty(String id, String merk, String jenis, String tipe, String tanggalProduksi) {
        this.id = new SimpleStringProperty(id);
        this.merk = new SimpleStringProperty(merk);
        this.jenis = new SimpleStringProperty(jenis);
        this.tipe = new SimpleStringProperty(tipe);
        this.tanggalProduksi = new SimpleStringProperty(tanggalProduksi);
    }
    public TasProperty(Tas ts){
        this.id = new SimpleStringProperty(ts.getId());
        this.merk = new SimpleStringProperty(ts.getMerk());
        this.jenis = new SimpleStringProperty(ts.getJenis());
        this.tipe = new SimpleStringProperty(ts.getTipe());
        this.tanggalProduksi = new SimpleStringProperty(ts.getTanggalProduksi());
    }
    public StringProperty getTanggalProduksiProperty() {
        return tanggalProduksi;
    }

    public void setTanggalProduksi(String tanggalProduksi) {
        this.tanggalProduksi= new SimpleStringProperty(tanggalProduksi);
    }

    public StringProperty getIdProperty() {
        return id;
    }

    public void setId(String id) {
        this.id = new SimpleStringProperty(id);
    }

    public StringProperty getMerkProperty() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = new SimpleStringProperty(merk);
    }

    public StringProperty getJenisProperty() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = new SimpleStringProperty(jenis);
    }

    public StringProperty getTipeProperty() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = new SimpleStringProperty(tipe);
    }

    public String getMerk() {
        return merk.get();
    }

    public String getId() {
        return id.get();
    }

    public String getJenis() {
        return jenis.get();
    }

    public String getTipe() {
        return tipe.get();
    }

    public String getTanggalProduksi() {
        return tanggalProduksi.get();
    }
    
}
