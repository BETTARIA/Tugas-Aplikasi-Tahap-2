package datatas.model;


public class Tas {
    private String id;
    private String merk;
    private String jenis;
    private String tipe;
    private String tanggal_produksi;
    public Tas(String id, String merk, String jenis, String tipe, String tanggal_produksi ) {
        this.id = id;
        this.merk = merk;
        this.jenis = jenis;
        this.tipe = tipe;
        this.tanggal_produksi = tanggal_produksi;
    }
    
 

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMerk() {
        return merk;
    }

    public void setmerek(String merk) {
        this.merk = merk;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getTanggal_produksi() {
        return tanggal_produksi;
    }

    public void setTanggal_produksi(String tanggal_produksi) {
        this.tanggal_produksi = tanggal_produksi;
    }

    String getTanggalProduksi() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}