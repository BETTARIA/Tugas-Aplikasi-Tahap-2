/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datatas.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import datatas.model.Tas;
import datatas.model.TasProperty;
import javafx.collections.ObservableList;

public class DBHandler {
    public final Connection conn;

    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addtas(Tas ts){
        String insertTas = "INSERT INTO `tas`(`id`, `merk`, `jenis`,`tipe`,`tanggal_produksi`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertTas);
            stmtInsert.setString(1, ts.getId());
            stmtInsert.setString(2, ts.getMerk());
            stmtInsert.setString(3, ts.getJenis());
            stmtInsert.setString(4, ts.getTipe());
            stmtInsert.setString(5, ts.getTanggal_produksi());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deleteDatatas(TasProperty ts) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ObservableList<TasProperty> Tas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
 